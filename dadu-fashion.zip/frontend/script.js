function shopNow(){
alert("Welcome to Dadu Fashion Shop!");
}
